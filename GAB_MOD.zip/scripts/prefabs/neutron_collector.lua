--oh babe, space time
local assets = {

}
local prefabs  = {

}

local mainFn = function()

end

return Prefab("neutron_collector", mainFn, assets, prefabs)