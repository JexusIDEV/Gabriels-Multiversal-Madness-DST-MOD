name = "Way to the GAB_ID's Multiversal Madness"
description = "An whole new experience.\nExplore the weird mechanics and multiverse of GAB_ID's, enjoying is characters and new items in your world.\nThank you for downloading the mod.\n¡Enjoy!"
author = "gab_id"
version = "1.0"
forumthread = ""

api_version = 10

client_only_mod = false
dst_compatible = true
all_clients_require_mod = true

icon_atlas = "modicon.xml"
icon = "modicon.tex"

priority = -1

configuration_options = {
    {
        name = "GABID_CharsLanguage",
        label = "Language",
        options = {
            {description = "English", data = "EN"},
            {description = "Spanish", data = "SP"},
        },
        default = "EN"
    }
}